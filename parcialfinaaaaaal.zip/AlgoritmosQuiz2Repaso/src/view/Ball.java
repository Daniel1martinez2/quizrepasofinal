package view;

import processing.core.PApplet;

public class Ball implements Runnable {
	
	int posx,posy,tamma, dirx, diry; 
	float r,g,b; 
	PApplet app; 

	public Ball(PApplet app, int posx, int posy, float r, float g, float b, int tamma) {
		this.app= app; 
		this.posx= posx; 
		this.posy= posy; 
		this.r= r; 
		this.g=g; 
		this.b= b; 
		this.tamma = tamma; 
		dirx = 1; 
		diry = 1; 
		
		
		
	}

	public void run() {
		try {
			Thread.sleep(2000);
			mover(); 
		} catch (InterruptedException e) {
			// TODO: handle exception
		}
		
	}
	
	public void pintar() {
		app.fill(r,g,b);
		app.ellipse(posx, posy, tamma, tamma);

	}
	
	public void mover() {
		posx+= app.random(1,5)*dirx; 
		posy+= app.random(1,5)*diry; 
		
		if(posx>app.height || posx<0
			) {
			dirx *= -1; 
		}
		if(posy>app.width||posy<0
				) {
				diry *= -1; 
			}
		
	}

	public int getTamma() {
		return tamma;
	}

	public void setTamma(int tamma) {
		this.tamma = tamma;
	}

	public int getDirx() {
		return dirx;
	}

	public void setDirx(int dirx) {
		this.dirx = dirx;
	}

	public int getDiry() {
		return diry;
	}

	public void setDiry(int diry) {
		this.diry = diry;
	}

	public float getR() {
		return r;
	}

	public void setR(float r) {
		this.r = r;
	}

	public float getG() {
		return g;
	}

	public void setG(float g) {
		this.g = g;
	}

	public float getB() {
		return b;
	}

	public void setB(float b) {
		this.b = b;
	}
	
	
	

}
