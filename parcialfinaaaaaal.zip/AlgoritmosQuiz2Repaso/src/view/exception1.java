package view;

public class exception1 extends Exception{

	
	private static final long serialVersionUID = 1L;

	public exception1(String message) {
		super(message); 
		
	}

}
