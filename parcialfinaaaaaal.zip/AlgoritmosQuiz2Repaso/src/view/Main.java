package view;

import java.util.ArrayList;

import processing.core.PApplet;

public class Main extends PApplet {
	ArrayList<Ball> balls; 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PApplet.main("view.Main");

	}
	public void settings() {
		size(600,600); 

	}

	public void setup() {
		balls = new ArrayList <Ball>(); 
		

	}

	public void draw() {
		background(0); 
		fill(100); 
		text("press 'D' to delete ", width/2 -100, 50); 
		try {
			for (int i = 0; i < balls.size(); i++) {
				balls.get(i).pintar();
				new Thread(balls.get(i)).start();
				for (int j = 0; j < balls.size(); j++) {
		
						
						choque(balls.get(j),balls.get(i)); 
				}
			}
		} catch (IndexOutOfBoundsException e) {
			System.out.println(balls.size()+"ay");
		}
	}
	public void mousePressed() {
	
		balls.add(new Ball(this, parseInt(random(0,600)), 
				 parseInt(random(0,600)), random(0,255),
				 random(0,255), random(0,255), parseInt(random(10,100)))); 
		
	}
	
	public void choque(Ball a,Ball b) {
		
		if(dist(a.posx,a.posy, b.posx,b.posy)<=(a.tamma/2)+b.tamma/2 && a!=b) {
			
			if(a.tamma > b.tamma &&b!=null && a!=null) {
				a.setTamma(a.getTamma()+b.getTamma());
				a.setR(b.getR());
				a.setG(b.getG());
				a.setB(b.getB());
				balls.remove(b); 
	
			}
			if(a.tamma ==b.tamma) {
				
				a.setDirx(a.getDirx()*-1);
				a.setDiry(a.getDiry()*-1);
				b.setDirx(b.getDirx()*-1);
				b.setDiry(b.getDiry()*-1);	
			}
		}
	}
	public void delete() throws exception1 {
		if(balls.size()==0 ) {
			
			throw new exception1("no se puede mas"); 
		}else {
			balls.remove(0);
		}
	}
	
	public void keyPressed() {
		try {
			if(key=='d') {
				delete();
				
			}
			
			
		} catch (exception1 e) {
			System.out.println(e.getMessage());
		}
		
	}

}
